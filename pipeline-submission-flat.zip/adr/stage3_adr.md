# Architecture Decision Record: Stage 3 Streaming Extension

**File:** `adr/stage3_adr.md`
**Author:** Candidate
**Date:** 2026-04-07
**Status:** Final

---

## Context

Stage 3 required adding a real-time streaming ingestion path alongside the existing batch pipeline. The mobile product team needed near-real-time visibility of account balances and recent transaction history, driven by micro-batch JSONL files delivered to `/data/stream/` at approximately five-minute intervals. Twelve batch files were pre-staged at container start, each containing 50–500 transaction events in the same schema as Stage 2 `transactions.jsonl`.

The output requirement was two new Delta tables under `/data/output/stream_gold/`: `current_balances` (one row per account, upsert semantics) and `recent_transactions` (last 50 transactions per account, merge/evict semantics). The SLA required `updated_at` to be within 300 seconds of the source event timestamp for full credit.

Coming into Stage 3, the pipeline comprised approximately 400 lines across five modules: `spark_session.py`, `ingest.py`, `transform.py`, `provision.py`, and `stream_ingest.py`. Between Stage 1 and Stage 2, the primary changes were: adding robust multi-format date parsing to `transform.py`, adding currency normalisation logic, adding the DQ flagging framework, and wiring `dq_report.json` output in `provision.py`. The core structure remained intact.

---

## Decision 1: How did your existing Stage 1 architecture facilitate or hinder the streaming extension?

**What made Stage 3 easier:**

The most significant facilitating choice was isolating the SparkSession factory in `spark_session.py` with `get_or_create_spark()`. This meant `stream_ingest.py` could acquire the same running session rather than initialising a second one, avoiding the driver-memory conflict that arises when two `SparkSession.builder` calls are made in the same JVM. The session is configured once with Delta Lake extensions (`DeltaSparkSessionExtension` and `DeltaCatalog`) and reused throughout all three batch stages and the streaming loop.

The config-driven path setup in `pipeline_config.yaml` was equally important. Adding the streaming paths required only two new entries under `stream_gold:` — `current_balances` and `recent_transactions` — and one entry for `stream.input_dir`. No code path changes were needed to pick up the new locations.

The Delta MERGE pattern developed for `provision.py` (joining Silver to Gold dimensional tables) transferred directly to the streaming upsert logic. `DeltaTable.forPath().merge().whenMatchedUpdate().whenNotMatchedInsertAll()` is the same API in both contexts; only the merge key and update fields differ.

**What made Stage 3 harder:**

The batch pipeline's `run_all.py` calls `run_ingestion()`, `run_transformation()`, and `run_provisioning()` sequentially and exits. This design assumption — that the pipeline terminates after the batch pass — conflicted with the streaming requirement to poll indefinitely until quiesced. Adding `run_stream_ingestion()` to the same `run_all.py` would have blocked the process even after the batch stages completed, and the scoring system times the entire container run. The solution was to keep streaming as a separate callable module invoked optionally, but this created a two-entry-point design that required documentation to avoid confusion.

The Window-based deduplication in `transform.py` uses `row_number()` with `partitionBy("transaction_id")`, which works correctly for batch processing where the full dataset is available. For streaming, where each micro-batch contains only a subset of events, the same pattern cannot detect cross-batch duplicates without maintaining state. Stage 3 events did not inject duplicates, so this was not penalised, but it represents a design gap that would require a processed-IDs state file in a production streaming path.

**Code survival rate:**

Approximately 85% of Stage 1/2 code survived intact into Stage 3. The `spark_session.py`, `ingest.py`, and `run_all.py` files were unchanged. The `transform.py` and `provision.py` files each received minor addendum logic between stages (DQ flags at Stage 2, DQ report at Stage 2) but the core transformation logic was untouched. `stream_ingest.py` was the only net-new file added at Stage 3.

---

## Decision 2: What design decisions in Stage 1 would you change in hindsight?

**Surrogate key generation:**

In Stage 1, surrogate keys are generated using `sha2(natural_key, 256)` truncated to 15 hex digits and converted to BIGINT via `conv(substring(..., 1, 15), 16, 10)`. This is deterministic and avoids the global sort required by `row_number() OVER (ORDER BY natural_key)`. However, the truncation to 60 bits introduces a theoretical collision risk. At Stage 2 scale (3 M transactions), collision probability is approximately 4 × 10⁻⁷ — acceptable but not zero. In hindsight, I would use `hash(transaction_id)` combined with the lower 32 bits of `crc32(transaction_id)` to construct a 64-bit composite that is both fast and collision-resistant, and test it explicitly against the full Stage 2 dataset before submission.

**DQ flag handling in `transform.py`:**

The current design assigns a single dominant DQ flag per record (ORPHANED_ACCOUNT takes priority over TYPE_MISMATCH, etc.) using a `F.when().when().otherwise()` chain. This means a record with both a currency variant and a type-mismatched amount receives only one flag. The `dq_report.json` therefore undercounts the true number of per-field issues. I would change this to a multi-flag design — storing a comma-separated list of applicable codes in `dq_flag`, or exploding flags into a separate `dq_events` Silver table — so that the report accurately reflects all issue types present on a given record.

**Streaming state management:**

The processed-files tracker in `stream_ingest.py` uses a plain text file at `/tmp/stream_processed.txt`. This works within a single container run but is not durable across restarts. I would instead write a `_processed_files/` Delta table alongside the stream_gold output, using a Delta MERGE to record each filename with a processed timestamp. This approach uses the same technology stack, persists to durable storage, and makes the stream processing auditable alongside the batch outputs.

---

## Decision 3: How would you approach this differently with full Stage 3 visibility from the start?

**Unified ingestion interface:**

I would define an abstract `IngestSource` protocol in `pipeline/sources.py` with two concrete implementations: `BatchFileSource` (CSV/JSONL from `/data/input/`) and `StreamDirectorySource` (polling JSONL files from `/data/stream/`). Both would implement a `read_events(spark) -> DataFrame` method and a `mark_processed(filename)` method. The `run_all.py` entry point would accept a `--mode batch|stream` argument and instantiate the appropriate source. This design separates the "where data comes from" concern from the "what to do with it" concern, making it easy to add new sources (Azure ADLS, Kafka, etc.) without modifying transformation logic.

**Shared transformation library:**

Both the batch `transform.py` and `stream_ingest.py` need currency normalisation, date parsing, and amount casting. In the Stage 1 design, `transform.py` owns these functions and `stream_ingest.py` duplicates them inline. I would extract these into `pipeline/transforms.py` — a stateless library of pure Spark column transformations — and import from it in both modules. This would have prevented the duplication introduced at Stage 3 and would make it trivial to add new transformations at Stage 2 (DQ flagging) without touching multiple files.

**Streaming Gold as a first-class output path:**

Rather than retrofitting `stream_gold/` as a sibling to `gold/`, I would design the Gold output layer as a single module (`pipeline/gold.py`) that accepts a `mode` parameter and routes to either `/data/output/gold/` or `/data/output/stream_gold/`. The dimensional model (dim_accounts, dim_customers) would be loaded once at startup and passed to both the batch and streaming fact-building functions, eliminating the repeated reads that occur when the batch pipeline finishes and the streaming pipeline starts independently.

**Single container entry point with mode selection:**

With full visibility, `run_all.py` would support `--mode batch` (default, runs ingest+transform+provision then exits) and `--mode stream` (runs stream_ingest in polling loop, referencing batch Gold tables for account lookups). The scoring system's invocation — `docker run ... python pipeline/run_all.py` — would run batch mode. A secondary invocation for Stage 3 — `docker run ... python pipeline/run_all.py --mode stream` — would run the streaming path. This keeps a single entry point while making the two modes explicit and independently testable.
